package com.pwc.sawtooth.handler;

import java.io.UnsupportedEncodingException;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.google.protobuf.ByteString;

import sawtooth.sdk.processor.State;
import sawtooth.sdk.processor.TransactionHandler;
import sawtooth.sdk.processor.Utils;
import sawtooth.sdk.processor.exceptions.InternalError;
import sawtooth.sdk.processor.exceptions.InvalidTransactionException;
import sawtooth.sdk.protobuf.TpProcessRequest;

public class HelloWorldHandler implements TransactionHandler {

	private final static String txnFamilyName = "helloworld";
	private final static String version = "1.0";
	private String simpleWalletNameSpace;

	public HelloWorldHandler() {
		super();
		try {
			this.simpleWalletNameSpace = Utils.hash512(txnFamilyName.getBytes("UTF-8")).substring(0, 3);
			System.out.println("NameSpace ====> " + simpleWalletNameSpace);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

	public void apply(TpProcessRequest request, State state) throws InvalidTransactionException, InternalError {
		String payload = request.getPayload().toStringUtf8();
		List<String> payloadList = new ArrayList<>(Arrays.asList(payload.split(",")));

		//String operation = payloadList.get(0);
		String data = payloadList.get(0);

		String userKey = request.getHeader().getSignerPublicKey();
		String walletKey = getWalletKey(userKey);

		System.out.println(" :: KEY :: " + userKey +" \n WALLET KEY :: "+ walletKey);
		System.out.println(" :: Data :: " + data);
			
		Map.Entry<String, ByteString> entry = new AbstractMap.SimpleEntry<String, ByteString>(walletKey,
		ByteString.copyFromUtf8(data.toString()));
		Collection<Map.Entry<String, ByteString>> newLedgerEntry = Collections.singletonList(entry);
		state.setState(newLedgerEntry);
	}

	public Collection<String> getNameSpaces() {
		List<String> namespaces = new ArrayList<>();
		namespaces.add(simpleWalletNameSpace);
		return namespaces;
	}

	public String getVersion() {

		return version;
	}

	public String transactionFamilyName() {

		return txnFamilyName;
	}

	private String getWalletKey(String userKey) {
		// Generate unique key(wallet key) from the wallet namespace
		// and user signer public key
		return Utils.hash512(txnFamilyName.getBytes()).substring(0, 3)
				+ Utils.hash512(userKey.getBytes()).substring(0, 64);
	}

}
