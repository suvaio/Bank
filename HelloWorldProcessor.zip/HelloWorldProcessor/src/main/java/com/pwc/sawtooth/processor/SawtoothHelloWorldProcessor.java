package com.pwc.sawtooth.processor;

import com.pwc.sawtooth.handler.HelloWorldHandler;

import sawtooth.sdk.processor.TransactionProcessor;

public class SawtoothHelloWorldProcessor {
 
	public static void main(String[] args) {
		// Connect to validator with connection string (tcp://validator:4004)
		TransactionProcessor simpleWalletProcessor = new TransactionProcessor(args[0]);
		// Create simple wallet transaction handler and register with the validator
		simpleWalletProcessor.addHandler(new HelloWorldHandler());
		Thread thread = new Thread(simpleWalletProcessor);
		//start the transaction processor
		thread.run();
	}
}
